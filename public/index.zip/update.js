
githubUrl="http://abner.shop/public/index.zip"

获取下载的脚本()
toastLog("更新完成")
// log("github下载的脚本=",github下载的脚本)
// engines.execScript('auto.js&github',github下载的脚本)
function 获取下载的脚本(){
  try{
    var r=http.get(githubUrl)
    log('code=',r.statusCode)
    var zipFile=r.body.bytes()
    if(zipFile){
      var 代码路径=保存zip文件(zipFile)
    //   return files.read(代码路径)
    }else{
      console.error('下载github代码失败')
      exit()
    }
  }catch(err){
    console.error(err)
    exit()
  }
}


function 保存zip文件(zipFile){
  var path=files.join(files.cwd(),"更新文件专用/update.zip")
  files.createWithDirs(path)
  log("path=",path)
  // path= /storage/emulated/0/脚本/zip文件专用/test.zip
  // var str = new java.lang.String(zipFile, java.nio.charset.Charset.forName("GBK"));
  // zipFile = str.getBytes();
  files.writeBytes(path,zipFile)
  var r=解压zip文件(path)
//   log(r)
  return r
}


function 解压zip文件(文件路径){
  //同一目录下的同一文件名
  var 文件夹路径=文件路径.replace(".zip", "")+"/"
  log('解压的文件夹路径=',文件夹路径)
  files.removeDir(文件夹路径)
  log("删除文件夹成功")
  files.createWithDirs(文件夹路径)
  log("创建文件夹成功")
  com.stardust.io.Zip.unzip(new java.io.File(文件路径), new java.io.File(文件夹路径))
  log("解压成功")
  updateFile()
//   return 文件夹路径+仓库名字+"-master"+"/index.js"
}

function updateFile(){
  log("更新文件。。。。")
    var updatePath = "更新文件专用/update/";
    var arr = files.listDir(updatePath);
    log(arr);
    for(var i=0;i<arr.length;i++){
        files.copy(updatePath+arr[i], "./"+arr[i])
    }
    
}


function 返回路径的父目录(path){
  var r=path.split("/")
  r[r.length-1]=""
  r=r.join('/')
  // 尾部带斜杆
  log("父目录=",r)
}
