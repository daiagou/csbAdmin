


"ui";
ui.layout(
    <vertical padding="16">
        

        <text textSize="16sp" textColor="black" text="请勾选需要运行的app"/>
        <checkbox id="check66" text="66dy" checked="false"/>
        <checkbox id="check66kuaishou" text="66快手" checked="false"/>
        <checkbox id="check99" text="99" checked="true"/>
        <checkbox id="checkzanzan" text="zanzan" checked="true"/>

        <text textSize="16sp" textColor="black" text="请输入dy个人名片地址"/>
        <input id="url" hint="在抖音，记录美好生活！ https://v.douyin.com/nP8M2P/" />
        <button id="ok" text="确定"/>

        <text marginTop="300px" text="日志"/>
        <com.stardust.autojs.core.console.ConsoleView  id="console" h="*"/>
    </vertical>
);

var localStorage = storages.create("6699");
loadCache();


ui.console.setConsole(runtime.console);
// 设置控制台字体颜色
let c = new android.util.SparseArray();
let Log = android.util.Log;
c.put(Log.VERBOSE, new java.lang.Integer(colors.parseColor("#dfc0c0c0")));
c.put(Log.DEBUG, new java.lang.Integer(colors.parseColor("#cc000000")));
c.put(Log.INFO, new java.lang.Integer(colors.parseColor("#ff64dd17")));
c.put(Log.WARN, new java.lang.Integer(colors.parseColor("#ff2962ff")));
c.put(Log.ERROR, new java.lang.Integer(colors.parseColor("#ffd50000")));
c.put(Log.ASSERT, new java.lang.Integer(colors.parseColor("#ffff534e")));
ui.console.setColors(c);


runtime.loadDex("./dy.dex");
importClass(com.qiqi.PersonInfo);
//指定确定按钮点击时要执行的动作
ui.ok.click(function(){
    // localStorage.put("url",ui.url.getText().toString());
    saveCache();
    threads.start(function(){
        start_6699();
    });

});

function saveCache(){
    var cacheData = {
        check66:ui.check66.isChecked(),
        check66kuaishou:ui.check66kuaishou.isChecked(),
        check99:ui.check99.isChecked(),
        checkzanzan:ui.checkzanzan.isChecked(),
        url:ui.url.getText().toString(),
    }
    log("save cache")
    log(cacheData)
    localStorage.put("cacheData",cacheData);
}
function loadCache(){
    var defaultCacheData = {
        check66:false,
        check66kuaishou:false,
        check99:false,
        checkzanzan:false,
        url:"",
    }
    var cacheData = localStorage.get("cacheData",defaultCacheData);
    log(cacheData)
    ui.check66.checked = cacheData.check66;
    ui.check66kuaishou.checked = cacheData.check66kuaishou;
    ui.check99.checked = cacheData.check99;
    ui.checkzanzan.checked = cacheData.checkzanzan;
    if(cacheData.url){
        ui.url.setText(cacheData.url);
    }else{
        var url = localStorage.get("url","");
        ui.url.setText(url);
    }
}
// ui.url.setText(url);

//启用按键监听
events.observeKey();
//监听音量上键按下
events.onKeyDown("volume_up", function(event){
    toast("音量上键被按下了");
    // exit();
    home();
    engines.stopAll();
});
//监听菜单键按下
events.onKeyDown("volume_down", function(event){
    toast("音量下键被按下了");
    // exit();
    home();
    engines.stopAll();
});

var zanzanPackageName = "com.zanqzan.app";
var ksPackageName = "com.smile.gifmaker";
var dyPackageName = "com.ss.android.ugc.aweme";
var sixsixPackageName = "com.toutiaozuqiu.and.liuliu";
var  jiujiuPackageName= "com.shoubang.vxread";

var currentFocus= 0;
var currentLike = 0;

var maxFailTimes = 2;
var currentFailTimes = 0;
var dyPersonUrl = "";



function checkDianZanNum(){
    var dianzan = currentLike;
    getDyInfo(dyPersonUrl);
    if(currentLike<=dianzan){
        log("点赞数量有误!!!!!!")
        currentFailTimes+=1;
        if(currentFailTimes>=maxFailTimes){
            home();
            engines.stopAll();

            yanghao();
        }
        return false;
    }
    return true;
}
function checkGuanZhuNum(){
    var guanzhu = currentFocus;
    getDyInfo(dyPersonUrl);
    if(currentFocus<=guanzhu){
        log("关注数量有误!!!!!!")
        currentFailTimes+=1;
        if(currentFailTimes>=maxFailTimes){
            home();
            engines.stopAll();


            yanghao();

        }
        return false;
    }
    return true;
}


function yanghao(){


    for(var i=0;i<600;i++){
        sleep(2000);
        toastLog("准备养号。。。")
    }

    if (!app.launchApp("抖音短视频")) {
        toastLog("没有找到抖音短视频app")
    }
    
    for(var i=0;i<2000;i++){
    
        clickUiBounds(text("以后再说"))
        clickUiBounds(text("我知道了"))
    
        toastLog("养号中..." + i)
        sleep(getRandom(10,28)*1000)
        swipe(700, device.height-300, 700, 300, 500);
    }
}

function getDyInfo(url){
    var personInfo = new PersonInfo();
    // var url="https://v.douyin.com/nP8M2P/";
    // log(url)
    log("调用前 关注:"+currentFocus+",点赞:"+currentLike);
    var info = personInfo.queryPersonInfo(url);
    // log(info)
    // log(info.focus)
    // log(info.like)
    currentFocus = info.focus;
    currentLike = info.like;
    log("调用后 关注:"+currentFocus+",点赞:"+currentLike);
}



function start_6699() {
    log("请确保开启无障碍服务哦~")

    auto.waitFor()
    
    setScreenMetrics(1080, 2340);
    requestScreenCapture(false);

    var tempUrl = ui.url.getText();
    tempUrl = tempUrl.toString();
    log(tempUrl)
    // 在抖音，记录美好生活！ https://v.douyin.com/nP8M2P/
    if(tempUrl.indexOf("在抖音")<0 ||tempUrl.indexOf("https")<0){
        toastLog("url不正确！！");
        return;
    }
    dyPersonUrl = tempUrl.substring(tempUrl.indexOf("https"));
    log(dyPersonUrl);
    // return;
    getDyInfo(dyPersonUrl);//初始化点赞关注数量
    


    for (var i = 0; i < 1000; i++) {

        if(ui.check66.isChecked()){
            start_66();
            home();
            sleep(1000)
        }
        if(ui.check66kuaishou.isChecked()){
            start_66ks();
            home();
            sleep(1000)
        }
        
        
        if(ui.checkzanzan.isChecked()){
            start_zanzan();
            home();
            sleep(1000)
        }

        if(ui.check99.isChecked()){
            start_99();
            home();
            sleep(1000);
        }
        
        
        
       
    }
}









function start_zanzan() {
    // app.launchApp("攒攒")

    if (!app.launchApp("攒攒")) {
        log("没有找到攒攒app")
        return;
    }

    // myWaitFor(packageName(jiujiuPackageName))

    for (var i = 0; i < 10; i++) {
        checkAppOpened(zanzanPackageName)
        if(textContains("授权").exists()){
            //return;
            }
        if (textContains("D音任务").exists()) {
            break;
        } else {
            back();
            // clickUiBounds(text("确定"));
        }
        sleep(2000);
    }


    if (textContains("D音任务").exists()) {
        // click(300, 500);//观看DY视频
        clickUiBounds(textContains("D音任务"))
        myWaitFor(text("领取任务"));
        sleep(1000)
        // clickUiBounds(text("领取任务"));
        //click(200,1350)
        swipe(500,1500,500,200,500)
        sleep(1000)
        // var a = text("领取任务").findOnce(1)
        // if(a){
        //     var bounds=a.bounds();
        //     click(bounds.centerX(),bounds.centerY());
            
        //     }
        var a = text("特价任务").find();
        var bounds=a[0].bounds();
        click(500,bounds.centerY()-100);
        for (var i = 0; i < 60; i++) {
            if (!read_zanzan()) {
                log("木有任务")
                back();
                return;
            }
        }
    }

}

function read_zanzan() {
    myWaitFor(text("提交任务"),5);
    sleep(1000)
    for(var i=0;i<10;i++){
        if(!text("任务截图").exists()){
            log("没有任务了");
            // exitApp();
            return false;
        }
        if(!text("任务截图").exists()){
            clickUiBounds(text("提交任务"));
            sleep(1000);
        }else{
             sleep(1000);
            break;
        }
        sleep(1000);
    }
    
   
    // clickUiBounds(text("领取任务"));
    // sleep(2000);
    // if (text("任务记录").exists()) {
    //     log("还在这个页面，说明没有任务了");
    //     // exitApp();
    //     return false;
    // }
    // myWaitFor(textContains("任务要求"));

    log("zanzan任务界面")

    //if (text("点赞").exists()) {// 任务类型：点赞
    if(textContains("点赞").boundsInside(device.width/2, 0, device.width, device.height / 2).exists()){
        clickUiBounds(textContains("直接做任务"));

        // myWaitFor(text("本任务需要"));

        // clickUiBounds(text("点赞"));

        myWaitFor(packageName(dyPackageName));
        clickUiBounds(textContains("跳过"))
        sleep(1000);
        sleep(1000);
        myWaitFor(textContains("检测到"),3);
        clickUiBounds(text("前往"));
        clickUiBounds(text("打开看看"));
        sleep(getRandom(10,20)*1000)
        if(clickUiBounds(text("以后再说"))){
            sleep(1000)
        }
        dianzan();
        simulateSysCapture();
        sleep(1000);
        // app.launchApp("攒攒")
        exitDy(zanzanPackageName);
        myWaitFor(text("任务截图"));
        if(checkDianZanNum()){
            uploadImg_zanzan();
        }else{
            back()
            sleep(1000);
            back()
        }
        // myWaitFor(text("知道了"), 20)//99可能有时候比较慢
        // clickUiBounds(text("知道了"));
        return true;
    }
    //if (text("关注").exists()) {//任务类型：关注
    if(textContains("关注").boundsInside(device.width/2, 0, device.width, device.height / 2).exists()){
        clickUiBounds(textContains("直接做任务"));
        // myWaitFor(text("本任务需要"));
        // clickUiBounds(text("关注"));
        myWaitFor(packageName(dyPackageName));
        clickUiBounds(textContains("跳过"))
        sleep(2000);
        myWaitFor(textContains("检测到"),3);
        clickUiBounds(text("前往"));
        clickUiBounds(text("打开看看"));
        sleep(getRandom(10,20)*1000)
        if(clickUiBounds(text("以后再说"))){
            sleep(1000)
        }

        // swipe(device.width - 100, 500, 100, 500, 500);//右滑
        // sleep(1000);

        click(800, 450);
        sleep(2000);
        if (clickUiBounds(text("取消")) || textContains("发送消息").exists()) {
            sleep(1000);
            back();
        }
        // sleep(1000);
        // swipe(100, 500, device.width - 100, 500, 500);//左滑
        // sleep(1000);
        if(text("刷新").exists()){
            sleep(999999999)
        }
        simulateSysCapture();
        sleep(1000);
        // app.launchApp("攒攒")
        exitDy(zanzanPackageName);
        myWaitFor(text("任务截图"));
        if(checkGuanZhuNum()){
            uploadImg_zanzan();
        }else{
            back()
            sleep(1000);
            back()
        }
       
        // myWaitFor(text("知道了"), 20)//99可能有时候比较慢
        // clickUiBounds(text("知道了"))
        return true;
        // }

    }
    log("zanzan沒有找到任务!!!!")
    //if (clickUiBounds(text("放弃任务"))) {
        back()
        sleep(1000);
        back()
        //clickUiBounds(text("确定"))
        //return true;
    //}
    return false;
}

function exitDy(toOpenPackage){
    for(var i=0;i<5;i++){
        // if(clickUiBounds(text("以后再说"))){
        //     sleep(1000)
        // }
        if(packageName(dyPackageName).exists()){
            back();
            sleep(400);
        }else{
            checkAppOpened(toOpenPackage);
            break;
        }
    }
}

function uploadImg_zanzan() {
    
    clickUiBounds(text("任务截图"))
    // if (clickUiBounds(id("image_jia"))) { 
    myWaitFor(text("选择图片")); // myWaitFor(packageName("com.google.android.documentsui"));
    sleep(1000);
    click(200, 380);//第一张图片的位置
    sleep(200);
    clickUiBounds(textContains("完成"))
    // }
    myWaitFor(packageName(zanzanPackageName))
    log(("提交myWaitFor任务"))

    sleep(5000);

    for(var i=0;i<20;i++){
        if(!text("任务截图").exists() && text("截图数量").exists()){
            // sleep(2000);
            clickUiBounds(text("提交任务"));
            sleep(1000)
            clickUiBounds(text("提交"))
        }else{
            // if(clickUiBounds(text("提交"))){
            //     sleep(1000)
            // }
            break;
        }
        sleep(2000);
    }
    log("提交任务")
    
}





function start_99() {
    // app.launchApp("99阅读")
    if (!app.launchApp("99阅读")) {
        log("没有找到99阅读app")
        return;
    }
    // myWaitFor(packageName(jiujiuPackageName))

    for (var i = 0; i < 10; i++) {
        checkAppOpened(jiujiuPackageName)
        if (text("任务中心").exists()) {
            break;
        } else {
            back();
            clickUiBounds(text("确定"));
        }
        sleep(2000);
    }

    // if (text("观看爆音视频").exists()) {
    clickUiBounds(text("赚积分"));//观看DY视频
    sleep(1000);
    if (text("领取任务").exists()) {
        click(300, 500);//再点一次，防止没点到
    }
    for (var i = 0; i < 60; i++) {
        if (!read_99()) {
            log("木有任务")
            back()
            return;
        }
    }
    // }

}

function read_99() {
    myWaitFor(text("领取任务"));
    sleep(1000);//防止转圈
    if (!text("领取任务").exists()) {
        log("没有任务了");
        // exitApp();
        return false;
    }
    
    // sleep(5000);
    for(var i=0;i<10;i++){
        clickUiBounds(text("领取任务"));
        sleep(1000);
        //if(!text("领取中").exists()){
        if(textContains("任务要求").exists()){
            break;
        }
    }
    
    // myWaitFor(textContains("任务要求"),5);
    myWaitForTwo(textContains("任务要求"),textContains("关注"),5);

    if (text("任务记录").exists()) {
        log("还在这个页面，说明没有任务了");
        // exitApp();
        return false;
    }


    if (textContains("点赞").exists()) {// 任务类型：点赞
        clickUiBounds(text("打开'DY'做任务"));

        myWaitForTwo(text("点赞"),packageName(dyPackageName));
        sleep(1000)
        clickUiBounds(text("点赞"))
        sleep(2000)
        if(!packageName(dyPackageName).exists()){
            clickUiBounds(text("确定"));
        }

        myWaitFor(packageName(dyPackageName));
        clickUiBounds(textContains("跳过"))
        sleep(2000);
        myWaitFor(textContains("检测到"),3);
        clickUiBounds(text("前往"));
        clickUiBounds(text("打开看看"));
        sleep(getRandom(10,20)*1000)
        if(clickUiBounds(text("以后再说"))){
            sleep(1000)
        }

        dianzan();
        captureAndSave();
        sleep(1000);
        // app.launchApp("99阅读")
        exitDy(jiujiuPackageName);
        uploadImg_99();
        // if(checkDianZanNum()){
        //     uploadImg_99();
        // }else{
        //     back()
        //     sleep(1000);
        //     back()
        // }
        
        // myWaitFor(text("知道了"), 30)//99可能有时候比较慢
        // clickUiBounds(text("知道了"));
        return true;
    }
    if(textContains("关注").exists()){
        click(500,1430)
        sleep(1000);
    }
    // if (textContains("关注").exists()) {//任务类型：关注
    //     clickUiBounds(text("打开'DY'做任务"));
    //     myWaitFor(text("本任务需要"));
    //     clickUiBounds(text("关注"));
        
    //     sleep(2000)
    //     clickUiBounds(text("确定"));
        
    //     myWaitFor(packageName("com.ss.android.ugc.aweme"));
    //     clickUiBounds(textContains("跳过"))
    //     sleep(1000);

    //     //swipe(device.width - 100, 500, 100, 500, 500);//右滑
    //    // sleep(2000);

    //     click(800, 450);
    //     sleep(2000);
    //     if (clickUiBounds(text("取消")) || textContains("发送消息").exists()) {
    //         sleep(1000);
    //         back();
    //     }
    //     sleep(1000);
    //     //swipe(100, 500, device.width - 100, 500, 500);//左滑
    //     //sleep(1000);
    //     if(text("刷新").exists()){
    //         sleep(999999999)
    //     }
    //     captureAndSave();
    //     sleep(1000);
    //     app.launchApp("99阅读")
    //     uploadImg_99();
    //     myWaitFor(text("知道了"), 30)//99可能有时候比较慢
    //     clickUiBounds(text("知道了"))
    //     return true;
    //     // }

    // }
    log("沒有找到任务!!!!")
    if (clickUiBounds(text("放弃任务"))) {
        sleep(1000);
        clickUiBounds(text("确定"))
        return true;
    }
    return false;
}

function uploadImg_99() {
    myWaitFor(text("示例图"));
    click(700, 1300)
    // clickUiBounds(id("image_jia"))
    // if (clickUiBounds(id("image_jia"))) { 
    myWaitFor(text("最近")); // myWaitFor(packageName("com.google.android.documentsui"));
    sleep(1000);
    click(200, 900);//第一张图片的位置
    // }
    myWaitFor(packageName(jiujiuPackageName))
    sleep(2000)
    clickUiBounds(text("提交任务"));
}






function start_66() {
    // app.launchApp("66联盟")
    if (!app.launchApp("66联盟")) {
        log("没有找到66联盟app")
        return;
    }
    myWaitFor(packageName(sixsixPackageName))

    for (var i = 0; i < 10; i++) {
        checkAppOpened(sixsixPackageName)
        if (text("任务中心").exists()) {
            break;
        } else {
            back();
            clickUiBounds(text("确定"));
        }
        sleep(2000);
    }


    do_66()

}


function start_66ks() {
    // app.launchApp("66联盟")
    if (!app.launchApp("66联盟")) {
        log("没有找到66联盟app")
        return;
    }
    myWaitFor(packageName(sixsixPackageName))

    for (var i = 0; i < 10; i++) {
        checkAppOpened(sixsixPackageName)
        if (text("任务中心").exists()) {
            break;
        } else {
            back();
            clickUiBounds(text("确定"));
        }
        sleep(2000);
    }


    do_66ks()
}


function do_66ks(){

    if (clickUiBounds(text("观看KS视频"))) {
        for (var i = 0; i < 30; i++) {
            if (!read_66ks()) {
                log("木有任务")
                return;
            }
        }
    }
}

function read_66ks() {
    myWaitFor(text("任务记录"));
    sleep(1000)
    if (!text("领取任务").exists()) {
        log("没有任务了");
        // exitApp();
        return false;
    }
    clickUiBounds(text("领取任务"));
    sleep(2000);
    if (text("任务记录").exists()) {
        log("还在这个页面，说明没有任务了");
        // exitApp();
        return false;
    }
    myWaitFor(textContains("任务要求"));

    // toastLog("111111111111")


    if (text("1、点赞").exists()) {
        clickUiBounds(text("打开“KS”做任务"));
        myWaitFor(packageName(ksPackageName));
        clickUiBounds(textContains("跳过"))
        sleep(3000);
        dianzan();
        captureAndSave();
        sleep(1000);
        app.launchApp("66联盟")
        sixsix_uploadImg();
        return true;
    }
    if (text("1、关注").exists()) {
        clickUiBounds(text("打开“KS”做任务"));
        myWaitFor(packageName(ksPackageName));
        clickUiBounds(textContains("跳过"))
        // toastLog("111111111111")
        myWaitFor(id("header_follow_button"),5);
        // toastLog("2222")
        sleep(1000);
        //click(900,150)
        //sleep(1000)
        clickUiBounds(id("header_follow_button"));
        
        sleep(2000);
        // for (var i = 0; i < 10; i++) {
        //     if (text("首页").exists()) {
        //         swipe(device.width - 100, 500, 100, 500, 500);//右滑
        //         sleep(1000);
        //     } else {
        //         break;
        //     }
        // }
        // if (clickGuanZhu()) {
            if(text("刷新").exists()){
            sleep(999999999)
            }
            captureAndSave();
            sleep(1000);
            app.launchApp("66联盟")
            sixsix_uploadImg();
            return true;
        // }

    }
    log("沒有找到任务!!!!")
    if (clickUiBounds(text("放弃任务"))) {
        sleep(1000);
        clickUiBounds(text("确定"))
        return true;
    }
    return false;
}


function do_66(){
    var ql = text("强烈推荐").findOne()
    var qlBounds = ql.bounds()
    click(500,qlBounds.centerY()+200);
    // if (clickUiBounds(text("观看爆音视频"))) {
        for (var i = 0; i < 30; i++) {
            if (!read_66()) {
                log("木有任务")
                return;
            }
        }
    // }
}

function read_66() {
    myWaitFor(text("任务记录"),5);
    myWaitFor(text("领取任务"),2);
    if (!text("领取任务").exists()) {
        log("没有任务了");
        // exitApp();
        return false;
    }
    clickUiBounds(text("领取任务"));
    sleep(2000);
    if (text("任务记录").exists()) {
        log("还在这个页面，说明没有任务了");
        // exitApp();
        return false;
    }
    myWaitForTwo(textContains("任务要求"),textContains("关注"),5);


    if (text("1、点赞").exists()) {
        clickUiBounds(text("打开“爆音”做任务"));
        myWaitFor(packageName(dyPackageName));
        clickUiBounds(textContains("跳过"))
        sleep(2000);
        myWaitFor(textContains("检测到"),3);
        clickUiBounds(text("前往"));
        clickUiBounds(text("打开看看"));
        sleep(getRandom(10,20)*1000)
        if(clickUiBounds(text("以后再说"))){
            sleep(1000)
        }
        dianzan();
        captureAndSave();
        sleep(1000);
        // app.launchApp("66联盟")
        exitDy(sixsixPackageName);
        sixsix_uploadImg();
        // if(checkDianZanNum()){
        //     sixsix_uploadImg();
        // }else{
        //     back()
        //     sleep(1000);
        //     back()
        // }
       
        return true;
    }
    if(textContains("关注").exists()){
        click(500,1430)
        sleep(1000);
    }
    // if (text("1、关注").exists()) {
    //     clickUiBounds(text("打开“爆音”做任务"));
    //     myWaitFor(packageName("com.ss.android.ugc.aweme"));
    //     clickUiBounds(textContains("跳过"))
    //     sleep(1000);
    //     for (var i = 0; i < 10; i++) {
    //         if (text("首页").exists()) {
    //             swipe(device.width - 100, 500, 100, 500, 500);//右滑
    //             sleep(1000);
    //         } else {
    //             break;
    //         }
    //     }
    //     if (clickGuanZhu()) {
    //         if(text("刷新").exists()){
    //         sleep(999999999)
    //         }
    //         captureAndSave();
    //         sleep(1000);
    //         app.launchApp("66联盟")
    //         sixsix_uploadImg();
    //         return true;
    //     }

    // }
    log("沒有找到任务!!!!")
    if (clickUiBounds(text("放弃任务"))) {
        sleep(1000);
        clickUiBounds(text("确定"))
        return true;
    }
    return false;
}

function sixsix_uploadImg() {
    myWaitFor(text("上传截图"));
    var a = text("上传截图").findOne();
    var x = a.bounds().centerX();
    var y = a.bounds().centerY()
    if (y < device.height / 2) {
        clickUiBounds(text("上传截图"));
        myWaitFor(text("最近")); // myWaitFor(packageName("com.google.android.documentsui"));
        sleep(1000);
        click(200, 900);//第一张图片的位置
    }
    myWaitFor(packageName(sixsixPackageName))
    sleep(2000)
    clickUiBounds(text("提交任务"));
}


function dianzan() {
    click(500, 500)
    sleep(50);
    click(500, 500)

    sleep(1000);

    click(500, 500)
    sleep(50);
    click(500, 500)
}






function clickGuanZhu() {
    if (text("取消关注").exists()) {
        log("已经关注了");
        return true;
    }

    var a = text("关注").clickable(true).find();
    if (a) {
        // log(a.length);
        for (var i = 0; i < a.length; i++) {

            // log(a[i]);
            var x = a[i].bounds().centerX();
            var y = a[i].bounds().centerY()

            if (x > 0 && x < device.width && y > 200 && y < device.height / 4) {
                // log(a[i].bounds())
                click(x, y);
                sleep(2000);
                return true;

            }
        }
    }

    return false;
}




/**
 *  不能点击的控件，通过坐标点击
 * @param {*} uiSelector
 */
function clickUiBounds(ui) {
    if (ui.exists()) {
        var a = ui.findOne();
        if (a) {
            var b = a.bounds();
            if (b) {
                click(b.centerX(), b.centerY());
                return true;
            }
        }

    }
    return false;
}

function clickUi(ui) {
    if (ui.exists()) {
        ui.findOne().click() //推送弹框
        return true;
    }
    return false;
}

function getRandom(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function queryAllScriptsByPhoneId(phoneId) {
    var url = "http://www.czsxdsy.com:8080/jiaoben/queryAllScriptsByPhoneId?phoneId=" + phoneId
    log(url)
    var r = http.get(url);
    var str = r.body.string();
    return str;
}
function queryAndAddTimes(phoneId, script) {
    var url = "http://www.czsxdsy.com:8080/jiaoben/queryAndAddTimes?phoneId=" + phoneId + "&script=" + script;
    log(url)
    var r = http.get(url);
    var str = r.body.string();
    return str;
}

function exitApp() {
    for (var i = 0; i < 5; i++) {
        back()
        sleep(200)
    }
}

function checkAppOpened(pname) {
    if (!packageName(pname).exists()) {
        app.launchPackage(pname);
        sleep(5000);
    }
}

function myWaitFor(ui, times) {
    times = times | 10
    for (var i = 0; i < times; i++) {
        if (ui.exists()) {
            sleep(200);
            return true;
        }
        sleep(1000);
    }
    return false;
}

function myWaitForTwo(ui,ui2, times) {
    times = times | 10
    for (var i = 0; i < times; i++) {
        if (ui.exists()||ui2.exists()) {
            sleep(200);
            return true;
        }
        sleep(1000);
    }
    return false;
}


function commonWatchVideo(times) {
    times = times | 15;
    for (var i = 0; i < times; i++) {
        log("观看视频" + i)
        sleep(2000);
    }
    back()
    sleep(1000)
}


function skipOpenAppAd(times) {
    imes = times | 10;
    for (var i = 0; i < times; i++) {
        if (clickUiBounds(text("跳过")) || clickUiBounds(desc("跳过"))) {
            break;
        }
        sleep(1000);
    }
}

function captureAndSave(path) {
    if (!path) {
        path = "/sdcard/screenshot.png";
    }
    //请求截图
    // requestScreenCapture(false);
    //截图
    var im = captureScreen();
    // var path = "/sdcard/screenshot.png";
    //保存图片
    im.saveTo(path);
    //把图片加入相册
    media.scanFile(path);
    return im;
}


function simulateSysCapture(path){
    if (!path) {
        path = path = "/storage/emulated/0/Pictures/Screenshots/Screenshot_20200113-123456.png";
    }
    if(files.exists(path)){
       files.removeDir(path)
        media.scanFile(path);
    }
    sleep(1000)
    captureAndSave(path)
}

