



log("请确保开启无障碍服务哦~")

auto.waitFor()

setScreenMetrics(1080, 2340);
// requestScreenCapture(false);

var appPackageName = "cn.youth.news";


if (!app.launchApp("中青看点")) {
    toastLog("没有找到中青看点app")
}

waitForPackage(appPackageName)

skipOpenAppAd()
toastLog("打开中青看点成功")



// shareCopyUrl()



// for (var i = 0; i < 10; i++) {
//     checkAppOpened(appPackageName)
//     if (text("推荐").exists()) {
//         break;
//     } else {
//         back();
//     }
//     sleep(2000);
// }


// start_zhongqingkandian()


// yueduwenzhang()

function start_zhongqingkandian(){

    for(var i=0;i<20;i++){


        for (var i = 0; i < 10; i++) {
            checkAppOpened(appPackageName)
            if (text("推荐").exists()) {
                break;
            } else {
                back();
            }
            sleep(2000);
        }

       
        if (text("推荐").exists()) {

    
           
            // if(clickUiBounds(text("新闻"))||clickUiBounds(text("刷新"))) //新闻
            click(100,2150);
            sleep(3000)
            // lingqushijianduan()
            // chaihongbao()
            swipe(100, 1300, 100, 300, 500)
            sleep(1000)
            xuanzewenzhang()
            
            swipe(100, 1300, 100, 300, 500)
            sleep(500)
            swipe(100, 1300, 100, 300, 500)
            sleep(1000)
            toastLog("上滑新闻")
            xuanzewenzhang()

            swipe(100, 1300, 100, 300, 500)
            sleep(500)
            swipe(100, 1300, 100, 300, 500)
            sleep(1000)
            toastLog("上滑新闻")
            xuanzewenzhang()

            sleep(1000)

           
        }
    }

}


function xuanzewenzhang() {
    var c = textEndsWith("阅读").find();
    // if (!c.empty()) {
    //     c = c.concat(textEndsWith("报").find())
    // }else {
    //     c = textEndsWith("报").find()
    // }
    if (!c.empty()) {
        for (var i = 1; i < c.length; i++) {
            var tv = c[i];
            toastLog("找到文章:"+tv.text())
            if (tv.bounds().centerX() > 0 && tv.bounds().centerX() < device.width && tv.bounds().centerY() > 0 && tv.bounds().centerY() < device.height - 200) {
                //第一个点了没积分的。
                click(100, tv.bounds().centerY() - 50)
                yueduwenzhang()
            }

        }
    }

}

function yueduwenzhang() {
    toastLog("阅读文章")
    var clickChaKan = false;
    for (var i = 0; i < 10; i++) {
        sleep(3000)
        if (!textContains("说说你的观点").exists()) {
            toastLog("没收益了")
            break;
        } else {
            if(!clickChaKan){ 
                if(text("查看全文，奖励更多").exists()){
                    var chakan = text("查看全文，奖励更多").findOne();
                    var bound = chakan.bounds();
                    if(bound.centerY()>100 && bound.centerY()<=device.height-200){
                        if (clickUiBounds(text("查看全文，奖励更多"))) {
                            sleep(1000);
                            clickChaKan = true;
                        }
                    }
                }
            }
            
            toastLog("阅读文章"+i);
            swipe(100, 1000, 100, 300, 300)

            if(i==9){
                if(clickUiBounds(id("vm"))){
                    sleep(2000);
                    if(text("阅读明细").exists()){
                        back();
                    }else{
                        sleep(5000);
                        clickUiBounds(id("nz"));
                    }
                    
                    sleep(1000)
                    
                }
            }
        }
    }

    shareCopyUrl();
    back();
    sleep(2000)
}




var clipUrl = "";
function shareCopyUrl(){
    if (!textContains("说说你的观点").exists()) {
        toastLog("没收益，不需要分享")
        return;
    }
    click(1000,2100);
    sleep(2000);
    clickUiBounds(text("复制链接"))
    sleep(1000);
    var tempUrl = getClip();
    if(tempUrl==''){
        app.launchApp("Auto.js")
        sleep(1000);
        tempUrl = getClip();
        sleep(1000);
        app.launchApp("中青看点")
        sleep(1000);
    }
    toastLog(tempUrl)
    if(tempUrl!=clipUrl){
        clipUrl = tempUrl;
        uploadUrl("中青看点",tempUrl);
    }
    // back();
    sleep(1000)
}

function uploadUrl(appName,url){
    var url = "http://abner.shop/saveUrls.php?appName="+appName+"&url="+url;
    toastLog(url)

    var r ;
    try {
        r = http.get(url);
     }
     catch(err){
         toastLog(err);
         return '';
     }

    // var r = http.get(url);
    var str = r.body.string();
    toastLog(str)
    return str;
}


/**
 *  不能点击的控件，通过坐标点击
 * @param {*} uiSelector
 */
function clickUiBounds(ui) {
    if (ui.exists()) {
        var a = ui.findOne();
        if (a) {
            var b = a.bounds();
            if (b) {
                click(b.centerX(), b.centerY());
                return true;
            }
        }

    }
    return false;
}

function clickUi(ui) {
    if (ui.exists()) {
        ui.findOne().click() //推送弹框
        return true;
    }
    return false;
}

function getRandom(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function queryAllScriptsByPhoneId(phoneId) {
    var url = "http://www.czsxdsy.com:8080/jiaoben/queryAllScriptsByPhoneId?phoneId=" + phoneId
    log(url)
    var r = http.get(url);
    var str = r.body.string();
    return str;
}
function queryAndAddTimes(phoneId, script) {
    var url = "http://www.czsxdsy.com:8080/jiaoben/queryAndAddTimes?phoneId=" + phoneId + "&script=" + script;
    log(url)
    var r = http.get(url);
    var str = r.body.string();
    return str;
}

function exitApp() {
    for (var i = 0; i < 5; i++) {
        back()
        sleep(200)
    }
}

function checkAppOpened(pname) {
    if (!packageName(pname).exists()) {
        app.launchPackage(pname);
        sleep(5000);
    }
}

function myWaitFor(ui, times) {
    times = times | 10
    for (var i = 0; i < times; i++) {
        if (ui.exists()) {
            sleep(200);
            return true;
        }
        sleep(1000);
    }
    return false;
}


function commonWatchVideo(times) {
    times = times | 15;
    for (var i = 0; i < times; i++) {
        log("观看视频" + i)
        sleep(2000);
    }
    back()
    sleep(1000)
}


function skipOpenAppAd(times) {
    imes = times | 10;
    for (var i = 0; i < times; i++) {
        if (clickUiBounds(text("跳过")) || clickUiBounds(desc("跳过"))) {
            break;
        }
        sleep(1000);
    }
}

function captureAndSave(path) {
    if (!path) {
        path = "/sdcard/screenshot.png";
    }
    //请求截图
    // requestScreenCapture(false);
    //截图
    var im = captureScreen();
    // var path = "/sdcard/screenshot.png";
    //保存图片
    im.saveTo(path);
    //把图片加入相册
    media.scanFile(path);
    return im;
}


function simulateSysCapture(path){
    if (!path) {
        path = path = "/storage/emulated/0/Pictures/Screenshots/Screenshot_20200113-123456.png";
    }
    if(files.exists(path)){
       files.removeDir(path)
        media.scanFile(path);
    }
    sleep(1000)
    captureAndSave(path)
}

